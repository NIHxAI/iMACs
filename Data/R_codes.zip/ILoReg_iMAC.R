#######################################################################################################################
#######################################################################################################################
#######################################################################################################################
#######################################################################################################################
#######################################################################################################################
#######################################################################################################################
#######################################################################################################################
#######################################################################################################################
#######################################################################################################################
#######################################################################################################################
#######################################################################################################################
#######################################################################################################################
#######################################################################################################################
#######################################################################################################################
#######################################################################################################################
#######################################################################################################################

#BiocManager::install('multtest')
#install.packages('Seurat')
library(Seurat)
library(cowplot)
library(patchwork)
library(dplyr)

#Seurat v4.0.2


##CMC3

##iMAC

#load dataset
hESC.data <- Read10X(data.dir = "./TBD180587_20180903/02_cellranger_file/01_sample/1/filtered_gene_bc_matrices/hg19")
head(hESC.data)
str(hESC.data)

#####	Creat Seurat object
#initialize the Seurat object with the raw (non-normalized data).
hESC <- CreateSeuratObject(counts = hESC.data , project = "hESC", min.cells = 5)

str(hESC)
hESC@assays$RNA@counts[1:5,1:5]
head(hESC@meta.data)
hESC

#####	QC metrics and filter cells
hESC[["percent.mt"]] <- PercentageFeatureSet(hESC, pattern = "^MT-")
head(hESC@meta.data)

VlnPlot(object = hESC, features = c("nFeature_RNA", "nCount_RNA", "percent.mt"), ncol = 3)

seurat.feature.plot1 <- FeatureScatter(object = hESC, feature1 = "nCount_RNA", feature2 = "percent.mt")
seurat.feature.plot2 <- FeatureScatter(object = hESC, feature1 = "nCount_RNA", feature2 = "nFeature_RNA")

CombinePlots(plots = list(seurat.feature.plot1, seurat.feature.plot2))

suppressMessages(library(ILoReg))
suppressMessages(library(SingleCellExperiment))
suppressMessages(library(cowplot))

##### filtering 
hESC.filt <- subset(x = hESC, subset = nFeature_RNA > 200 & percent.mt < 20)
dim(hESC.filt@meta.data) # the number of filtered cells / categories of the meta data
hESC.filt

hESC.filt <- NormalizeData(object = hESC.filt, normalization.method = "LogNormalize", scale.factor = 10000)

hESC.log <- SingleCellExperiment(assays = list(logcounts = hESC.filt@assays$RNA@data))
hESC.log <- PrepareILoReg(hESC.log)
hESC.log
hESC.log1 <- RunParallelICP(object = hESC.log, k = 15, d = 0.3, L = 30, r = 5, C = 0.3, reg.type = "L1", threads = 2)



hESC.log1 <- RunPCA(hESC.log1,p=50,scale = FALSE)
PCAElbowPlot(hESC.log1)
hESC.log1 <- RunUMAP(hESC.log1)
hESC.log1 <- RunTSNE(hESC.log1,perplexity=30)

GeneScatterPlot(hESC.log1,c("CD14","CD68","CD163","B2M","CD38","CD19"),
                dim.reduction.type = "umap",
                point.size = 0.3)

GeneScatterPlot(hESC.log1,c("CD14","CD68","CD163","B2M","CD38","CD19"),
                dim.reduction.type = "tsne",
                point.size = 0.3)



hESC.log1 <- HierarchicalClustering(hESC.log1)


hESC.log1 <- CalcSilhInfo(hESC.log1,K.start = 2,K.end = 50)
SilhouetteCurve(hESC.log1,return.plot = FALSE)

pdf("K_cluster_umap.pdf",width=8, height=8)

for(i in 2:9) {
hESC.log1 <- SelectKClusters(hESC.log1,K=i)

ClusteringScatterPlot(hESC.log1,
                                dim.reduction.type = "umap",
                                return.plot = FALSE,
                                title = "UMAP",
                                show.legend=FALSE)
}
dev.off()


pdf("K_cluster_tsne.pdf",width=8, height=8)

for(i in 2:9) {
hESC.log1 <- SelectKClusters(hESC.log1,K=i)
ClusteringScatterPlot(hESC.log1,
                                dim.reduction.type = "tsne",
                                return.plot = FALSE
                                ,title="t-SNE",
                                show.legend=FALSE)
}
dev.off()


plot_grid(ClusteringScatterPlot(hESC.log1,
                                dim.reduction.type = "umap",
                                return.plot = TRUE,
                                title = "UMAP",
                                show.legend=FALSE),
          ClusteringScatterPlot(hESC.log1,
                                dim.reduction.type = "tsne",
                                return.plot = TRUE
                                ,title="t-SNE",
                                show.legend=FALSE),
          ncol = 1
)

hESC.log1 <- SelectKClusters(hESC.log1,K=5)

VlnPlot(hESC.log1,genes = c("CD14","CD68","CD163","B2M","CD38","CD19"),return.plot = FALSE,rotate.x.axis.labels = TRUE)

gene_markers <- FindAllGeneMarkers(hESC.log1,
                                   clustering.type = "manual",
                                   test = "wilcox",
                                   log2fc.threshold = 0.25,
                                   min.pct = 0.25,
                                   min.diff.pct = NULL,
                                   pseudocount.use = 1,
                                   min.cells.group = 3,
                                   return.thresh = 0.01,
                                   only.pos = TRUE,
                                   max.cells.per.cluster = NULL)

genes_log2FC <- SelectTopGenes(gene_markers,
                               top.N = 14575,
                               criterion.type = "log2FC",
                               inverse = FALSE)
write.table(genes_log2FC, "hESC.DEGs.txt", sep="\t", row.names=F)


top10_log2FC <- SelectTopGenes(gene_markers,
                               top.N = 10,
                               criterion.type = "log2FC",
                               inverse = FALSE)
top1_log2FC <- SelectTopGenes(gene_markers,
                              top.N = 1,
                              criterion.type = "log2FC",
                              inverse = FALSE)
top10_adj.p.value <- SelectTopGenes(gene_markers,
                                    top.N = 10,
                                    criterion.type = "adj.p.value",
                                    inverse = TRUE)
top1_adj.p.value <- SelectTopGenes(gene_markers,
                                   top.N = 1,
                                   criterion.type = "adj.p.value",
                                   inverse = TRUE)
pdf("top1.pdf", height= 15, width=10)                                   
GeneScatterPlot(hESC.log1,
                genes = unique(top1_log2FC$gene),
                dim.reduction.type = "tsne",
                point.size = 0.5,ncol=2)                                  
dev.off()
 
pdf("top10_Heatmap.pdf", height= 15, width=10)                                   
               
GeneHeatmap(hESC.log1,
            clustering.type = "manual",
            gene.markers = top10_log2FC)
            
dev.off()
                            
                                   
                                   
hESC.log1 <- CalcSilhInfo(hESC.log1,K.start = 2,K.end = 50)
SilhouetteCurve(hESC.log1,return.plot = FALSE)




#######################################################################################################################
#######################################################################################################################
#######################################################################################################################
#######################################################################################################################
#######################################################################################################################
#######################################################################################################################
#######################################################################################################################
#######################################################################################################################
#######################################################################################################################
#######################################################################################################################
#######################################################################################################################
#######################################################################################################################
#######################################################################################################################
#######################################################################################################################
#######################################################################################################################
#######################################################################################################################

#BiocManager::install('multtest')
#install.packages('Seurat')
library(Seurat)
library(cowplot)
library(patchwork)
library(dplyr)

#Seurat v4.0.2


##CMC3

##iMAC

#load dataset
CMC.data <- Read10X(data.dir = "./TBD210425_20210503/02_cellranger_file/01_sample/CMC3/filtered_feature_bc_matrix/")
#head(CMC3.data)
#str(CMC3.data)

#####	Creat Seurat object
#initialize the Seurat object with the raw (non-normalized data).
CMC3 <- CreateSeuratObject(counts = CMC.data , project = "CMC3", min.cells = 5)

str(CMC3)
CMC3@assays$RNA@counts[1:5,1:5]
head(CMC3@meta.data)
CMC3

#####	QC metrics and filter cells
CMC3[["percent.mt"]] <- PercentageFeatureSet(CMC3, pattern = "^MT-")
head(CMC3@meta.data)

VlnPlot(object = CMC3, features = c("nFeature_RNA", "nCount_RNA", "percent.mt"), ncol = 3)

seurat.feature.plot1 <- FeatureScatter(object = CMC3, feature1 = "nCount_RNA", feature2 = "percent.mt")
seurat.feature.plot2 <- FeatureScatter(object = CMC3, feature1 = "nCount_RNA", feature2 = "nFeature_RNA")

CombinePlots(plots = list(seurat.feature.plot1, seurat.feature.plot2))

suppressMessages(library(ILoReg))
suppressMessages(library(SingleCellExperiment))
suppressMessages(library(cowplot))

##### filtering 
CMC3.filt <- subset(x = CMC3, subset = nFeature_RNA > 200 & percent.mt < 20)
dim(CMC3.filt@meta.data) # the number of filtered cells / categories of the meta data
CMC3.filt

CMC3.filt <- NormalizeData(object = CMC3.filt, normalization.method = "LogNormalize", scale.factor = 10000)

CMC3.log <- SingleCellExperiment(assays = list(logcounts = CMC3.filt@assays$RNA@data))
CMC3.log <- PrepareILoReg(CMC3.log)
CMC3.log
CMC3.log1 <- RunParallelICP(object = CMC3.log, k = 15, d = 0.3, L = 30, r = 5, C = 0.3, reg.type = "L1", threads = 2)



CMC3.log1 <- RunPCA(CMC3.log1,p=50,scale = FALSE)
PCAElbowPlot(CMC3.log1)
CMC3.log1 <- RunUMAP(CMC3.log1)
CMC3.log1 <- RunTSNE(CMC3.log1,perplexity=30)

GeneScatterPlot(CMC3.log1,c("CD14","CD68","CD163","B2M","CD38","CD19"),
                dim.reduction.type = "umap",
                point.size = 0.3)

GeneScatterPlot(CMC3.log1,c("CD14","CD68","CD163","B2M","CD38","CD19"),
                dim.reduction.type = "tsne",
                point.size = 0.3)

CMC3.log1 <- HierarchicalClustering(CMC3.log1)


CMC3.log1 <- CalcSilhInfo(CMC3.log1,K.start = 2,K.end = 50)
SilhouetteCurve(CMC3.log1,return.plot = FALSE)

pdf("CMC3_K_cluster_umap.pdf",width=8, height=8)

for(i in 2:9) {
CMC3.log1 <- SelectKClusters(CMC3.log1,K=i)

ClusteringScatterPlot(CMC3.log1,
                                dim.reduction.type = "umap",
                                return.plot = FALSE,
                                title = "UMAP",
                                show.legend=FALSE)
}
dev.off()


pdf("CMC3_K_cluster_tsne.pdf",width=8, height=8)

for(i in 2:9) {
CMC3.log1 <- SelectKClusters(CMC3.log1,K=i)
ClusteringScatterPlot(CMC3.log1,
                                dim.reduction.type = "tsne",
                                return.plot = FALSE
                                ,title="t-SNE",
                                show.legend=FALSE)
}
dev.off()


plot_grid(ClusteringScatterPlot(CMC3.log1,
                                dim.reduction.type = "umap",
                                return.plot = TRUE,
                                title = "UMAP",
                                show.legend=FALSE),
          ClusteringScatterPlot(CMC3.log1,
                                dim.reduction.type = "tsne",
                                return.plot = TRUE
                                ,title="t-SNE",
                                show.legend=FALSE),
          ncol = 1
)

CMC3.log1 <- SelectKClusters(CMC3.log1,K=9)

VlnPlot(CMC3.log1,genes = c("CD14","CD68","CD163","B2M","CD38","CD19"),return.plot = FALSE,rotate.x.axis.labels = TRUE)

gene_markers <- FindAllGeneMarkers(CMC3.log1,
                                   clustering.type = "manual",
                                   test = "wilcox",
                                   log2fc.threshold = 0.25,
                                   min.pct = 0.25,
                                   min.diff.pct = NULL,
                                   pseudocount.use = 1,
                                   min.cells.group = 3,
                                   return.thresh = 0.01,
                                   only.pos = TRUE,
                                   max.cells.per.cluster = NULL)

genes_log2FC <- SelectTopGenes(gene_markers,
                               top.N = 16392,
                               criterion.type = "log2FC",
                               inverse = FALSE)
write.table(genes_log2FC, "CMC3.DEGs.txt", sep="\t", row.names=F)



top10_log2FC <- SelectTopGenes(gene_markers,
                               top.N = 10,
                               criterion.type = "log2FC",
                               inverse = FALSE)
top1_log2FC <- SelectTopGenes(gene_markers,
                              top.N = 1,
                              criterion.type = "log2FC",
                              inverse = FALSE)
top10_adj.p.value <- SelectTopGenes(gene_markers,
                                    top.N = 10,
                                    criterion.type = "adj.p.value",
                                    inverse = TRUE)
top1_adj.p.value <- SelectTopGenes(gene_markers,
                                   top.N = 1,
                                   criterion.type = "adj.p.value",
                                   inverse = TRUE)
pdf("CMC3_top1.pdf", height= 15, width=10)                                   
GeneScatterPlot(CMC3.log1,
                genes = unique(top1_log2FC$gene),
                dim.reduction.type = "tsne",
                point.size = 0.5,ncol=2)                                  
dev.off()
 
pdf("CMC3_top10_Heatmap.pdf", height= 15, width=10)                                   
               
GeneHeatmap(CMC3.log1,
            clustering.type = "manual",
            gene.markers = top10_log2FC)
            
dev.off()
                            
                                   
  




























#####################################################################################################
### rare population ####
BiocManager::install("SC3")
BiocManager::install("scater")
BiocManager::install("SingleCellExperiment")

library(SingleCellExperiment)
library(SC3)
library(scater)
library(scanpy)
library(dplyr)
library(Matrix)

library(hdf5r)
library(iterators)
library(ggplot2)

CMC3_sce <- Convert(from = CMC3, to = "sce")


CMC3_log <- SetAssayData(object = CMC3.filt, slot = "data", 
                         new.data = log2(exp(as.matrix(GetAssayData(object = CMC3.filt, slot = "data")))))

CMC3_sce <- SingleCellExperiment(assays=list(counts=GetAssayData(object = CMC3_log, slot = "data")))

CMC3_sce


plotPCA(CMC3_sce, colour_by = "orig_ident")
plotPCA(CMC3_sce)


# create a SingleCellExperiment object
sce <- SingleCellExperiment(
  assays = list(
    counts = as.matrix(yan),
    logcounts = log2(as.matrix(yan) + 1)
  ), 
  colData = ann
)

# define feature names in feature_symbol column
rowData(CMC3_sce)$feature_symbol <- rownames(CMC3_sce)
# remove features with duplicated names
CMC3_sce <- CMC3_sce[!duplicated(rowData(CMC3_sce)$feature_symbol), ]

#logcounts
logcounts(CMC3_sce) <- log(GetAssayData(object = CMC3_log))

#Run SC3
sce <- sc3(CMC3_sce, ks = 2:4, biology = TRUE, n_cores = 8)

plotPCA(sce, colour_by = "cell_type1")












