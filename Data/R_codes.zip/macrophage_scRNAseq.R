#workinig directory
getwd()
setwd("/Users/bioinformatics/Desktop/hyeyeongJo/macrophage/scRNAseq/")
getwd()
dir()

save.image("macrophage_scRNAseq.RData")

#BiocManager::install('multtest')
#install.packages('Seurat')
library(Seurat)
library(cowplot)
library(patchwork)
library(dplyr)

#Seurat v4.0.2


##CMC3

#load dataset
CMC.data <- Read10X(data.dir = "./TBD210425_20210503/02_cellranger_file/01_sample/CMC3/filtered_feature_bc_matrix/")
head(CMC3.data)
str(CMC3.data)

#####	Creat Seurat object
#initialize the Seurat object with the raw (non-normalized data).
CMC3 <- CreateSeuratObject(counts = CMC.data , project = "CMC3", min.cells = 5)

str(CMC3)
CMC3@assays$RNA@counts[1:5,1:5]
head(CMC3@meta.data)
CMC3

counts_per_gene <- Matrix::rowMeans(CMC3)

counts <- CMC3@assays$RNA@counts
head(counts)

counts <- CMC3.filt@assays$RNA@counts

write.csv(counts_per_gene, file="CMC3.countmtx.csv")

install.packages("SeuratObject")
library(SeuratObject)
count.data <- GetAssayData(object = CMC3[["RNA"]], slot = "counts") 
count.data

#####	QC metrics and filter cells
CMC3[["percent.mt"]] <- PercentageFeatureSet(CMC3, pattern = "^MT-")
head(CMC3@meta.data)

VlnPlot(object = CMC3, features = c("nFeature_RNA", "nCount_RNA", "percent.mt"), ncol = 3)

seurat.feature.plot1 <- FeatureScatter(object = CMC3, feature1 = "nCount_RNA", feature2 = "percent.mt")
seurat.feature.plot2 <- FeatureScatter(object = CMC3, feature1 = "nCount_RNA", feature2 = "nFeature_RNA")

CombinePlots(plots = list(seurat.feature.plot1, seurat.feature.plot2))


##### filtering 
CMC3.filt <- subset(x = CMC3, subset = nFeature_RNA > 200 & percent.mt < 25)
dim(CMC3.filt@meta.data) # the number of filtered cells / categories of the meta data
CMC3.filt



VlnPlot(object = CMC3.filt, features = c("nFeature_RNA", "nCount_RNA", "percent.mt"), ncol = 3)

CMC3.filt.nor <- NormalizeData(object = CMC3.filt, normalization.method = "LogNormalize", scale.factor = 10000)
CMC3.filt.nor.var <- FindVariableFeatures(object = CMC3.filt.nor, selection.method = "vst", nfeatures = 2000)

CMC3_v.genes <- VariableFeatures(object = CMC3.filt.nor.var)

LabelPoints(plot = VariableFeaturePlot(CMC3.filt.nor.var), points = CMC3_v.genes[1:10], repel = T)

#identify the 10 most highly variable genes
top10 <- head(VariableFeatures(CMC3), 10)


DefaultAssay(object = CMC3.filt.nor.var) <- "RNA"

##### scaling the data
all.genes <- rownames(CMC3)
CMC3.scale <- ScaleData(CMC3.filt.nor.var, features = all.genes)


##### perform linear dimensional reduction
CMC3.PCA <- RunPCA(CMC3.scale, features = VariableFeatures(object = CMC3.scale))

print(CMC3.PCA[["pca"]], dims = 1:5, nfeatures = 5)

VizDimLoadings(CMC3.PCA, dims = 1:2, reduction = "pca")



DimPlot(CMC3.PCA, reduction = "pca")

DimHeatmap(CMC3.PCA, dims = 1, cells = 500, balanced = TRUE)
DimHeatmap(CMC3.PCA, dims = 1:9, cells = 500, balanced = TRUE)

##### determine the dimensionality of the dataset
ElbowPlot(object = CMC3.PCA)
CMC3.PCA.jack <- JackStraw(object = CMC3.PCA, num.replicate = 100, dims = 50)
CMC3.PCA.jack <- ScoreJackStraw(object = CMC3.PCA.jack, dims = 1:20)

JackStrawPlot(object = CMC3.PCA.jack, dims = 1:20)
ElbowPlot(object = CMC3.PCA.jack)


##### cluster the cells

#UMAP and clustering

CMC3.fn <- FindNeighbors(object = CMC3.PCA.jack, reduction = "pca", dims = 1:13)
CMC3.clusters <- FindClusters(CMC3.fn, resolution = 0.5)


CMC3.clusters.umap <- RunUMAP(object = CMC3.clusters , reduction = "pca", dims = 1:13)


DimPlot(CMC3.clusters.umap, reduction = "umap", pt.size = 2)




#visualization
p1 <- DimPlot(object = data.combined.clusters, reduction = "umap", group.by = "orig.ident", pt.size = 1.5)
p2 <- DimPlot(object = data.combined.clusters, reduction = "umap", label = TRUE, label.size = 10, pt.size=1.5)
plot_grid(p1, p2)


DimPlot(object = data.combined.clusters, reduction = "umap", 
        split.by = "orig.ident", pt.size = 1.5, label.size = 15)


CMC3.clusters.umap.tree <- buildClusterTree(CMC3.clusters.umap, do.reorder = TRUE,reorder.numeric = FALSE, pcs.use = 1:10)
PlotClusterTree(CMC3.clusters.umap.tree)


PrintFindClustersParams(object = CMC3.clusters.umap)


### Plots

VlnPlot(CMC3.clusters.umap, features = c("CD14", "CD68", "CD163", "B2M", "CD38", "CD19"))
FeaturePlot(CMC3.clusters.umap, features = c("CD14", "CD68", "CD163", "B2M", "CD38", "CD19"))

VlnPlot(CMC3.clusters.umap, features = c("CD3", "CD4", "CD25", "Foxp3", "CD38", "CD30", "CD31"))
FeaturePlot(CMC3.clusters.umap, features = c("CD3", "CD4", "CD25", "Foxp3", "CD38", "CD30", "CD31"))


n_cells <- FetchData(CMC3.clusters.umap, vars = "orig_ident") %>%
  group_by("orig_ident") %>%
  dplyr::count(ident) %>%
  spread(ident, n)

### finding differentially expressed markers

# find markers for every cluster compared to all remaining cells, report only the positive ones
CMC3.clusters.umap.markers <- FindAllMarkers(CMC3.clusters.umap, only.pos = TRUE, min.pct = 0.1, logfc.threshold = 0.25)
CMC3.clusters.umap.markers %>%
  group_by(cluster) %>%
  top_n(n = 2, wt = avg_log2FC)


head(CMC3.clusters.umap.markers)

write.csv(CMC3.clusters.umap@meta.data, file="CMC3.clusters.umap.metadata.csv")


#heatmap
top10 <- CMC3.clusters.umap.markers %>%
  group_by(cluster) %>%
  top_n(n = 10, wt = avg_log2FC)


DoHeatmap(CMC3.clusters.umap, features = top10$gene) + NoLegend()


#counts of genes in each cell

sum(GetAssayData(object = CMC3.clusters, slot = "data")["CD19",]>0)


#######################################################################################################################


##iMAC

#load dataset
hESC.data <- Read10X(data.dir = "./TBD180587_20180903/02_cellranger_file/01_sample/1/filtered_gene_bc_matrices/hg19")
head(hESC.data)
str(hESC.data)

#####	Creat Seurat object
#initialize the Seurat object with the raw (non-normalized data).
hESC <- CreateSeuratObject(counts = hESC.data , project = "hESC", min.cells = 5)

str(hESC)
hESC@assays$RNA@counts[1:5,1:5]
head(hESC@meta.data)
hESC

#####	QC metrics and filter cells
hESC[["percent.mt"]] <- PercentageFeatureSet(hESC, pattern = "^MT-")
head(hESC@meta.data)

VlnPlot(object = hESC, features = c("nFeature_RNA", "nCount_RNA", "percent.mt"), ncol = 3)

seurat.feature.plot1 <- FeatureScatter(object = hESC, feature1 = "nCount_RNA", feature2 = "percent.mt")
seurat.feature.plot2 <- FeatureScatter(object = hESC, feature1 = "nCount_RNA", feature2 = "nFeature_RNA")

CombinePlots(plots = list(seurat.feature.plot1, seurat.feature.plot2))


##### filtering 
hESC.filt <- subset(x = hESC, subset = nFeature_RNA > 200 & percent.mt < 25)
dim(hESC.filt@meta.data) # the number of filtered cells / categories of the meta data
hESC.filt

VlnPlot(object = hESC.filt, features = c("nFeature_RNA", "nCount_RNA", "percent.mt"), ncol = 3)

hESC.filt.nor <- NormalizeData(object = hESC.filt, normalization.method = "LogNormalize", scale.factor = 10000)
hESC.filt.nor.var <- FindVariableFeatures(object = hESC.filt.nor, selection.method = "vst", nfeatures = 2000)

hESC_v.genes <- VariableFeatures(object = hESC.filt.nor.var)

LabelPoints(plot = VariableFeaturePlot(hESC.filt.nor.var), points = hESC_v.genes[1:10], repel = T)

#identify the 10 most highly variable genes
top10 <- head(VariableFeatures(hESC), 10)


##### scaling the data
all.genes <- rownames(hESC)
hESC.scale <- ScaleData(hESC.filt.nor.var, features = all.genes)


##### perform linear dimensional reduction
hESC.PCA <- RunPCA(hESC.scale, features = VariableFeatures(object = hESC.scale))

print(hESC.PCA[["pca"]], dims = 1:5, nfeatures = 5)

VizDimLoadings(hESC.PCA, dims = 1:2, reduction = "pca")



DimPlot(hESC.PCA, reduction = "pca")

DimHeatmap(hESC.PCA, dims = 1, cells = 500, balanced = TRUE)
DimHeatmap(hESC.PCA, dims = 1:9, cells = 500, balanced = TRUE)


##### determine the dimensionality of the dataset
ElbowPlot(object = hESC.PCA)
hESC.PCA.jack <- JackStraw(object = hESC.PCA, num.replicate = 100, dims = 50)
hESC.PCA.jack <- ScoreJackStraw(object = hESC.PCA.jack, dims = 1:20)

JackStrawPlot(object = hESC.PCA.jack, dims = 1:20)
ElbowPlot(object = hESC.PCA.jack)


##### cluster the cells

#UMAP and clustering

hESC.fn <- FindNeighbors(object = hESC.PCA.jack, reduction = "pca", dims = 1:13)
hESC.clusters <- FindClusters(hESC.fn, resolution = 0.5)


hESC.clusters.umap <- RunUMAP(object = hESC.clusters , reduction = "pca", dims = 1:13)


DimPlot(hESC.clusters.umap, reduction = "umap", pt.size = 2)


#visualization
p1 <- DimPlot(object = data.combined.clusters, reduction = "umap", group.by = "orig.ident", pt.size = 1.5)
p2 <- DimPlot(object = data.combined.clusters, reduction = "umap", label = TRUE, label.size = 10, pt.size=1.5)
plot_grid(p1, p2)


DimPlot(object = data.combined.clusters, reduction = "umap", 
        split.by = "orig.ident", pt.size = 1.5, label.size = 15)


hESC.clusters.umap.tree <- BuildClusterTree(hESC.clusters.umap)
PlotClusterTree(hESC.clusters.umap.tree)


### Plots

VlnPlot(hESC.clusters.umap, features = c("CD14", "CD68", "CD163", "B2M", "CD38", "CD19"))
FeaturePlot(hESC.clusters.umap, features = c("CD14", "CD68", "CD163", "B2M", "CD38", "CD19"))


VlnPlot(hESC.clusters.umap, features = c("CD3", "CD4", "CD25", "FOXP3", "CD38", "CD30", "CD31"))
FeaturePlot(hESC.clusters.umap, features = c("CD14", "CD68", "CD163", "B2M", "CD40L", "CD19"))




### finding differentially expressed markers

# find markers for every cluster compared to all remaining cells, report only the positive ones
hESC.clusters.umap.markers <- FindAllMarkers(hESC.clusters.umap, only.pos = TRUE, min.pct = 0.25, logfc.threshold = 0.25)
hESC.clusters.umap.markers %>%
  group_by(cluster) %>%
  top_n(n = 2, wt = avg_log2FC)


head(hESC.clusters.umap.markers)

write.csv(hESC.clusters.umap.markers, file="hESC.clusters.umap.markers.markers_0.25.csv")

##heatmap

top10 <- hESC.clusters.umap.markers %>%
  group_by(cluster) %>%
  top_n(n=10, wt = avg_log2FC)

DoHeatmap(hESC.clusters.umap, features = top10$gene, size = 4)


#heatmap
top10 <- hESC.clusters.umap.markers %>%
  group_by(cluster) %>%
  top_n(n = 10, wt = avg_log2FC)

DoHeatmap(hESC.clusters.umap.markers, features = top10$gene) + NoLegend()

#Vln Plot
VlnPlot(hESC.clusters.umap, features = c("PFN2","LARP6"))
VlnPlot(hESC.clusters.umap, features = c("LDOC1", "CNN1"))

#feature plot
FeaturePlot(hESC.clusters.umap, features = c("PFN2","LARP6", "LDOC1", "CNN1"))

#counts of genes in each cell

sum(GetAssayData(object = hESC.clusters, slot = "data")["CD19",]>0)



#####################################################################################################
### rare population ####
BiocManager::install("SC3")
BiocManager::install("scater")
BiocManager::install("SingleCellExperiment")

library(SingleCellExperiment)
library(SC3)
library(scater)
library(scanpy)
library(dplyr)
library(Matrix)

library(hdf5r)
library(iterators)
library(ggplot2)

CMC3_sce <- Convert(from = CMC3, to = "sce")


CMC3_log <- SetAssayData(object = CMC3.filt, slot = "data", 
                         new.data = log2(exp(as.matrix(GetAssayData(object = CMC3.filt, slot = "data")))))

CMC3_sce <- SingleCellExperiment(assays=list(counts=GetAssayData(object = CMC3_log, slot = "data")))

CMC3_sce


plotPCA(CMC3_sce, colour_by = "orig_ident")
plotPCA(CMC3_sce)


# create a SingleCellExperiment object
sce <- SingleCellExperiment(
  assays = list(
    counts = as.matrix(yan),
    logcounts = log2(as.matrix(yan) + 1)
  ), 
  colData = ann
)

# define feature names in feature_symbol column
rowData(CMC3_sce)$feature_symbol <- rownames(CMC3_sce)
# remove features with duplicated names
CMC3_sce <- CMC3_sce[!duplicated(rowData(CMC3_sce)$feature_symbol), ]

#logcounts
logcounts(CMC3_sce) <- log(GetAssayData(object = CMC3_log))

#Run SC3
sce <- sc3(CMC3_sce, ks = 2:4, biology = TRUE, n_cores = 8)

plotPCA(sce, colour_by = "cell_type1")












